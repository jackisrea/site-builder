function login() {
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;
    if(user && pass) {
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('builder-screen').style.display = 'block';
    } else {
        alert('Enter username and password!');
    }
}

function preview() {
    const html = document.getElementById('html-code').value;
    const css = `<style>${document.getElementById('css-code').value}</style>`;
    const js = `<script>${document.getElementById('js-code').value}<\/script>`;
    const iframe = document.getElementById('preview-frame').contentWindow.document;
    iframe.open();
    iframe.write(html + css + js);
    iframe.close();
}
